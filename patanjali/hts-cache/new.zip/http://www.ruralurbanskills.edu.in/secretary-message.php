<!DOCTYPE html>
<html lang="en">
<head>

	<!-- start: Meta -->
	<meta charset="utf-8">
	<title>Rural Urban Council of Skills & Vocational Studies Secretary Message to Students & Centers</title> 
    <meta name="description" content="The basic purpose of our Rural Urban Council of Skills & Vocational Studies Institute is to make education and employment education easily and easily accessible to deprived children and femininity for any reason. Contribute to promote Indian culture and values. The path to the goal can be difficult, but not impossible. Small efforts only determine the direction of change.">
    
<meta name="keywords" content="Rural Urban Council of Skills & Vocational Studies Secretary Message to Students & Centers">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		
    <link rel="shortcut icon" href="img/rucsvsicon.png" />
	
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/bootstrap-responsive.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Sans:400,700">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Serif">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Boogaloo">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Economica:700,400italic">
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-124030743-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-124030743-1');
</script>
</head>
<body>
	
	
	<div id="wrapper" style="border-radius:10px;border:2px solid blue">
				<div class="container-fluid">
			<header>
				<div class="row" style="margin-left:0px">
					<div class="logo span12">
						<a class="brand" href="#"><img src="/img/logo.gif"></a>
					</div>
				</div>
						
			</header>
			<div class="navbar navbar-inverse" style="margin-bottom:0px">
    			<div class="navbar-inner">
        			<div class="container">
          				<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
            				<span class="icon-bar"></span>
            				<span class="icon-bar"></span>
            				<span class="icon-bar"></span>
          				</a>
          				<div class="nav-collapse collapse" >
            				<ul class="nav">
              					<li class="active" style="border-right:1px solid white"><a href="http://www.ruralurbanskills.edu.in"><b>Home</b></a></li>
              					<li style="border-right:1px solid white" class="dropdown">
                					<a href="#" class="dropdown-toggle" data-toggle="dropdown"><b>About Us</b> <b class="caret" style="color:white"></b></a>
                					<ul class="dropdown-menu">
                  						<li><a href="http://www.ruralurbanskills.edu.in/about.php" target="_blank">About Us</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/about.php" target="_blank">Vision/ Mission</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/director-message.php" target="_blank">Director Message</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/secretary-message.php" target="_blank">Secretary Message</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/why-rucsvs.php" target="_blank">Why RUCSVS</a></li>
                                        <li><a href="http://www.ruralurbanskills.edu.in/team.php" target="_blank">Team Members</a></li>
                                        <li><a href="http://www.ruralurbanskills.edu.in/rti.php" target="_blank">RTI</a></li>
                					</ul>
              					</li>
								<li style="border-right:1px solid white"><a href="http://www.ruralurbanskills.edu.in/trade-courses.php" target="_blank"><b>Trade Courses</b></a></li>
								<li style="border-right:1px solid white"><a href="http://www.ruralurbanskills.edu.in/course-list.php" target="_blank"><b>Courses</b></a></li>
              					<li style="border-right:1px solid white" class="dropdown">
                					<a href="#" class="dropdown-toggle" data-toggle="dropdown"><b>Student Zone</b> <b class="caret" style="color:white"></b></a>
                					<ul class="dropdown-menu">
                                        <li><a href="http://www.ruralurbanskills.edu.in/student-verification.php" target="_blank">Verification</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/admitcard-list.php" target="_blank">Admit Card</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/result-list.php" target="_blank">Result</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/exam-download.php" target="_blank">Datesheet</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/admission-enquiry.php" target="_blank">Admission Form</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/syllabus.php">Syllabus</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/course-list.php" target="_blank">Courses</a></li>
										<li><a href="http://www.ruralurbanskills.edu.in/student-benefits.php">Student Benefits</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/downloads/Rural%20Urban%20Council%20of%20Skills%20Prospectus.pdf" target="_blank">Prospectus</a></li>
										<li><a href="http://www.ruralurbanskills.edu.in/cancellation-policy.php" target="_blank">Cancellation Policy</a></li>
                                        <li><a href="http://www.ruralurbanskills.edu.in/student-terms.php" target="_blank">Terms & Conditions</a></li>
                  						
										
										
                					</ul>
              					</li>
								<li style="border-right:1px solid white" class="dropdown">
                					<a href="#" class="dropdown-toggle" data-toggle="dropdown"><b>Downloads</b> <b class="caret" style="color:white"></b></a>
                					<ul class="dropdown-menu">
                  						<li><a href="http://www.ruralurbanskills.edu.in/approvals-download.php" target="_blank">Approval Letters </a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/center-download.php" target="_blank">Centers Download Zone</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/student-download.php" target="_blank">Student Download Zonesheet</a></li>
                                        <li><a href="http://www.ruralurbanskills.edu.in/exam-download.php">Exam Download Zonesheet</a></li>
                                        <li><a href="http://www.ruralurbanskills.edu.in/downloads/RUCSVS-Courses-&-Code.pdf" target="_blank">Courses Code</a></li>
                                        <li><a href="http://www.ruralurbanskills.edu.in/center-benefits.php" target="_blank">Centers Benefits</a></li>
                                        <li><a href="http://www.ruralurbanskills.edu.in/news-press-release.php" target="_blank">News/ Press Release</a></li>
                  						
                					</ul>
              					</li>
								<li style="border-right:1px solid white"><a href="http://www.ruralurbanskills.edu.in/centre-list.php" target="_blank"><b>Centre List</b></a></li>
              					<li style="border-right:1px solid white"><a href="http://www.ruralurbanskills.edu.in/apply-center.php" target="_blank"><b>Apply Centre</b></a></li>
              					<li style="border-right:1px solid white"><a href="http://www.ruralurbanskills.edu.in/contact.php" target="_blank"><b>Contact</b></a></li>
              					
								
            				</ul>
          				</div>
        			</div>
      			</div>
    		</div>
            
			<!--end: Navigation-->
			
		</div>
		<!--end: Container-->
		
				<!--end: Container-->
				
		<!--start: Container -->
    	<div class="container-fluid" style="padding-top:10px">
	      <div class="row">
		 
		  <div class="span3" style="background-color:#68cdfb;border-radius:5px">
		  <div style="padding-left:5px;padding-right:5px">
                     <h4 class="mycolor" style="color:white;padding:8px;text-align:center;margin-bottom:0px">Information About</h4>
		<div style="background:#68cdfb;margin-bottom:5px;">
       
					<ul style="color:red;padding:10px;" class="text-center">
					<li style="background: url(/img/bullet1.gif) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/sitemap.php"  style="color:black" target="_blank"><p style="color:black;padding-left:15px;font-weight:600;margin-top:10px">All Pages Sitemap</p></a></li>
					<hr style="border-top: 1px solid blue;border-bottom: 1px solid #0088cc;margin:0px">
				    <li style="background: url(/img/bullet1.gif) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/student-verification.php"  style="color:black" target="_blank"><p style="color:black;padding-left:15px;font-weight:600;margin-top:10px">Verification</p></a></li>
					<hr style="border-top: 1px solid blue;border-bottom: 1px solid #0088cc;margin:0px">
					<li style="background: url(/img/bullet1.gif) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/apply-center.php"  style="color:black" target="_blank"><p style="color:black;padding-left:15px;font-weight:600;margin-top:10px">Apply Center</p></a></li>
					<hr style="border-top: 1px solid blue;border-bottom: 1px solid #0088cc;margin:0px">
					<li style="background: url(/img/bullet1.gif) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/center-login-panel.php"  style="color:black" target="_blank"><p style="color:black;padding-left:15px;font-weight:600;margin-top:10px">Center Login Panel</p></a></li>
					<hr style="border-top: 1px solid blue;border-bottom: 1px solid #0088cc;margin:0px">
					<li style="background: url(/img/bullet1.gif) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/center-download.php"  style="color:black" target="_blank"><p style="color:black;padding-left:15px;font-weight:600;margin-top:10px">Center Download</p></a></li>
					<hr style="border-top: 1px solid blue;border-bottom: 1px solid #0088cc;margin:0px">
					<li style="background: url(/img/bullet1.gif) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/admission-enquiry.php"  style="color:black" target="_blank"><p style="color:black;padding-left:15px;font-weight:600;margin-top:10px">Apply Admission Zone</p></a></li>
					<hr style="border-top: 1px solid blue;border-bottom: 1px solid #0088cc;margin:0px">
					<li style="background: url(/img/bullet1.gif) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/course-list.php"  style="color:black" target="_blank"><p style="color:black;padding-left:15px;font-weight:600;margin-top:10px">Courses & Duration</p></a></li>
					<hr style="border-top: 1px solid blue;border-bottom: 1px solid #0088cc;margin:0px">
					<li style="background: url(/img/bullet1.gif) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/student-download.php"  style="color:black" target="_blank"><p style="color:black;padding-left:15px;font-weight:600;margin-top:10px">Student Downloads</p></a></li>
					<hr style="border-top: 1px solid blue;border-bottom: 1px solid #0088cc;margin:0px">
					<li style="background: url(/img/bullet1.gif) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/centers-terms.php"  style="color:black" target="_blank"><p style="color:black;padding-left:15px;font-weight:600;margin-top:10px">Center Terms & Conditions</p></a></li>
					<hr style="border-top: 1px solid blue;border-bottom: 1px solid #0088cc;margin:0px">
					<li style="background: url(/img/bullet1.gif) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/approvals.php"  style="color:black" target="_blank"><p style="color:black;padding-left:15px;font-weight:600;margin-top:10px">Recognition</p></a></li>
					<hr style="border-top: 1px solid blue;border-bottom: 1px solid #0088cc;margin:0px">
					<li style="background: url(/img/bullet1.gif) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/centre-list.php"  style="color:black" target="_blank"><p style="color:black;padding-left:15px;font-weight:600;margin-top:10px">Centers List</p></a></li>
					<hr style="border-top: 1px solid blue;border-bottom: 1px solid #0088cc;margin:0px">
					<li style="background: url(/img/bullet1.gif) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/approvals-download.php"  style="color:black" target="_blank"><p style="color:black;padding-left:15px;font-weight:600;margin-top:10px">Approval Downloads</p></a></li>
<hr style="border-top: 1px solid blue;border-bottom: 1px solid #0088cc;margin:0px">
<li style="background: url(/img/bullet1.gif) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/all-centers.php"  style="color:black" target="_blank"><p style="color:black;padding-left:15px;font-weight:600;margin-top:10px">All Centers</p></a></li>
					
					</ul></div>                        </div>
						 <div style="padding-left:5px;padding-right:5px;margin-top:10px">
                    <h4 class="mycolor" style="color:white;padding:8px;text-align:center">Latest News/Notice</h4>
		<div style="background:white;margin-bottom:5px;">
          <marquee direction="up" onMouseOver="this.stop();" onMouseOut="this.start();">
				
					<ul style="color:red;padding:10px;" class="text-center"><li style="background: url(img/bullet.png) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/admission-enquiry.php"  style="color:black" target="_blank"><h5 style="color:black;padding-left:15px;"> Apply Admission</h5></a></li>
					<hr>
				<li style="background: url(img/bullet.png) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/result-list.php"  style="color:black" target="_blank"><h5 style="color:black;padding-left:15px;"> Student Results</h5></a></li>
					<hr>
					<li style="background: url(img/bullet.png) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/approvals-download.php"  style="color:black" target="_blank"><h5 style="color:black;padding-left:15px;"> Approvals</h5></a></li>
					<hr>
					<li style="background: url(img/bullet.png) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/student-download.php"  style="color:black" target="_blank"><h5 style="color:black;padding-left:15px;"> Student Downloads</h5></a></li>
					<hr>
					<li style="background: url(img/bullet.png) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/center-download.php"  style="color:black" target="_blank"><h5 style="color:black;padding-left:15px;"> Center Downloads</h5></a></li>
					<hr>
					<li style="background: url(img/bullet.png) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/apply-center.php"  style="color:black" target="_blank"><h5 style="color:black;padding-left:15px;"> Apply Study Center/ Franchise</h5></a></li>
					<hr>
					<li style="background: url(img/bullet.png) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/downloads/IN6989A-ISO.pdf"  style="color:black" target="_blank"><h5 style="color:black;padding-left:15px;"> ISO Certification</h5></a></li>
					
					</ul></marquee></div>
                        </div>
						
						</div>
		  
		  
			<!-- start: Flexslider -->
			<div class="span9">
			<div style="padding:20px">
			<!-- start: About Us -->
					<div id="about">
						<div class="title"><h1>SECRETARY MESSAGE</h1></div>
						<p style="text-align:justify"><font size="+1" style="font-family: Georgia, "Times New Roman", Times, serif">
							वर्तमान समय में शिक्षा के बढ़ते स्तर के साथ तकनीकी और रोजगारपरक शिक्षा का महत्व भी बढ़ रहा है। आज के तकनीकी युग में बौद्धिक शिक्षा भी तकनीकी माध्यमों से दी जा रही है। 
बड़ा भौगोलिक क्षेत्र नहीं, बड़ा हुआ तकनीकी ज्ञान ही किसी भी देश की विशालता व खुशहलता का मापदंड है।
भारतीय संस्कृति और संस्कारों में प्राचीन समय से ही तकनीकी शिक्षा का समावेश रहा है। परंपरा और तकनीकी शिक्षा का यह अदभुत संगम भारतीय संस्कृति में देखने को मिलता है। देश की पारंपरिक हस्त-कला का जवाब आज भी विश्व में नहीं है।<br><br>
हस्त-कला न केवल हमारा जीवनयापन का सरल व सुगम माध्यम है, ये हमें परंपरा व संस्कारों से जोड़े रखती है।

अगर नई तकनीक के साथ पारंपरिक हस्त-कला का समावेश कर दें, तो हम अच्छे स्तर पर जीवनयापन कर सकते हैं, साथ ही देश के विकास में अपना दायित्व ईमानदारी से निभा सकते हैं।<br><br>
हमारा नैतिक कर्तव्य होगा कि घर-घर, जन-जन तक शिक्षा पहुंचाएं। क्योंकि शिक्षा से ही व्यक्ति अपना जीवन स्तर सुधार कर देश के विकास में सहयोग दे सकता है। शिक्षा के बिना जीवन अर्थहीन सा हो जाता है। 

बच्चे देश का भविष्य होते हैं। वर्तमान ही भविष्य की नींव है।अतः बच्चों को शिक्षित करना अनिवार्यता बन जाती है। आज भी शिक्षा के अभाव में अनेक बच्चे नारकीय जीवन जीने को मजबूर हैं। बहुत से बच्चे आर्थिक अभाव के चलते बचपन जी ही नहीं पाते। अशिक्षा के चलते अपराध की राह भटक जाते हैं। बच्चों के भविष्य पर ही देश का भविष्य निर्भर करता है। अतः हर बच्चे को शिक्षित करना सरकार का ही नहीं, हर नागरिक का कर्तव्य है। सरकार के साथ सहयोग करते हुए हम सबको घर-घर शिक्षा रूपी दीप जलाना होगा। <br><br>

वहीं बात आधी आबादी की आती है, तो हमें नहीं भूलना चाहिए कि नारी न केवल सृष्टि की जननी है, वह संस्कारों की जननी और संवाहक है। अतः नारी का शिक्षित होना ही किसी भी परिवार, समाज और राष्ट्र के संस्कारित होने, विकसित होने और आर्थिक रूप से संपन्न होने का पैमाना तय करता है। नारी शिक्षित होगी, आत्मनिर्भर होगी तो विकास और सम्पन्नता की लहर को कोई रोक नहीं सकता।
<br><br>
हमारे ट्रस्ट का मूल उद्देश्य है, किसी भी कारण से शिक्षा से वंचित बच्चों व नारीशक्ति को शिक्षा व रोजगारपरक शिक्षा सहज व सरल रूप से सुलभ करवाना। भारतीय संस्कृति व संस्कारों को बढ़ावा देने में अपना योगदान देना। लक्ष्य की राह कठिन हो सकती है, पर असंभव नहीं। छोटे-छोटे  प्रयास ही परिवर्तन की दिशा तय करते हैं।<br><br>

SECRETARY & HEAD<br>
Ms. Sonika Tiwari
</p></font>
					</div>	
					<!-- end: About Us -->

					

				
						
					</div>
					</div>
			</div>
			<!-- end: Hero Unit -->
			
				
            </div>
			
			
			  <div class="container-fluid">
      		<!-- start: Row -->
			<hr/>
      		<div class="row" style="text-align:center;">
	
        		<div class="span2" style="border:4px solid #1AB255;">
          			<a href="#"><div class="icons-box" >
						<i style="color:red" class="circle big"><img src="/img/admission.png" alt="Rural Urban Council of Skills & Vocational Studies"></i>
						<div class=""><h4>Student Zone</h4></div>
						
						<div class="clear"></div>
					</div></a>
        		</div>

        		<div class="span2" style="border:4px solid #1AB255;margin-left:0px">
          			<a href="http://www.ruralurbanskills.edu.in/admitcard.php" target="_blank"><div class="icons-box">
						<i style="color:red" class="circle big1"><img src="/img/student.png" alt="Rural Urban Council of Skills & Vocational Studies"></i>
						<div class=""><h4>Admit Card</h4></div>
						
						<div class="clear"></div>
					</div></a>
        		</div>

        		<div class="span2" style="border:4px solid #1AB255;margin-left:0px">
          			<a href="http://www.ruralurbanskills.edu.in/result.php" target="_blank"><div class="icons-box" >
						<i style="color:red" class="circle big2"><img src="/img/book.png" alt="Rural Urban Council of Skills & Vocational Studies"></i>
						<div class=""><h4>Result</h4></div>
					
						<div class="clear"></div>
					</div></a>
        		</div>
				
				<div class="span2" style="border:4px solid #1AB255;margin-left:0px">
          			<a href="#"><div class="icons-box" >
						<i style="color:red" class="circle big3"><img src="/img/online.png" alt="Rural Urban Council of Skills & Vocational Studies"></i>
						<div class=""><h4>Syllabus</h4></div>
					
						<div class="clear"></div>
					</div></a>
        		</div>
				
				<div class="span2" style="border:4px solid #1AB255;margin-left:0px">
          			<a href="http://www.ruralurbanskills.edu.in/admission-enquiry.php" target="_blank"><div class="icons-box" >
						<i style="color:red" class="circle big4"><img src="/img/result.png" alt="Rural Urban Council of Skills & Vocational Studies"></i>
						<div class=""><h4>Apply Admission</h4></div>
					
						<div class="clear"></div>
					</div></a>
        		</div>
				
				<div class="span2" style="border:4px solid #1AB255;margin-left:0px">
          			<a href="http://www.ruralurbanskills.edu.in/apply-center.php" target="_blank"><div class="icons-box">
						<i style="color:red" class="circle big5"><img src="/img/new.png" alt="Rural Urban Council of Skills & Vocational Studies"></i>
						<div class=""><h4>Apply Centre</h4></div>
					
						<div class="clear"></div>
					</div></a>
        		</div>

      		</div>
			<hr/>			<!-- end: Row -->
      		<div class="row">
			<div class="span2" style="background-color:white;text-align:center">
			<img src="img/beti.png" style="height:120px"/>
			
			</div>
			<div class="span2" style="background-color:white;text-align:center">
			<img src="img/beti2.png" style="height:120px"/>
			
			</div>
			<div class="span2" style="background-color:white;text-align:center">
			<img src="img/skill.png" style="height:120px"/>
			
			</div>
			<div class="span3" style="background-color:white;text-align:center">
			<img src="img/shiksha.jpg" style="height:120px"/>
			
			</div>
			<div class="span3" style="background-color:white;text-align:center">
			<img src="img/swach.jpg" style="height:120px"/>
			
			</div>
			
			
			</div>
			<hr>
			
		
			
		</div>
		<!--end: Container-->
					<!--start: Container -->
    	<div class="container-fluid">		

      		<div id="footer">
			
				<!-- start: Container -->
				<div class="container">
				
					<!-- start: Row -->
					<div class="row">

						<!-- start: About -->
						<div class="span3">
						
							<h3 style="text-align:center">About Us</h3>
							<p>
								This is a small step to decide on your participation in Skillful India, but by making a meaningful effort with sincere and transparent thinking, we will continue to make every effort to make it a milestone. <br /> <strong><font size="+1">For Center Apply Helpline 09560192015 , 09899822580</font> </strong>
							</p>
							
						</div>
						<!-- end: About -->

						<!-- start: Photo Stream -->
						<div class="span3">
						
							<h3 style="text-align:center">Downloads</h3>
							<div class="">
							<ul style="text-align:center">
							<li><a href="http://www.ruralurbanskills.edu.in/downloads/Admission-Form.pdf" target="_blank"><h4 style="color:white">Admission Form</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/downloads/Rural%20Urban%20Council%20of%20Skills%20Prospectus.pdf" target="_blank"><h4 style="color:white">Prospectus</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/downloads/Examination%20Center%20Request%20Form.pdf" target="_blank"><h4 style="color:white">Exam Center Form</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/downloads/dublicate%20marksheet%20form.pdf" target="_blank"><h4 style="color:white">Duplicate Marksheet</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/downloads/marksheet-correction-form.pdf" target="_blank"><h4 style="color:white">Correction Form</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/downloads/Re-Registration-Form.pdf" target="_blank"><h4 style="color:white">Re Registration</h4></a></li>
							
							</ul>
								<div class="clear"></div>
							</div>
						
						</div>
						<!-- end: Photo Stream -->
                        <div class="span3">
						
							<h3 style="text-align:center">Student Zone</h3>
							<div class="">
							<ul style="text-align:center">
							<li><a href="http://www.ruralurbanskills.edu.in/admission-enquiry.php" target="_blank"><h4 style="color:white">Apply Admission</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/result-list.php" target="_blank"><h4 style="color:white">Result Zone</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/admitcard-list.php" target="_blank"><h4 style="color:white">Admit Card</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/student-verification.php" target="_blank"><h4 style="color:white">Online Verification</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/exam-download.php" target="_blank"><h4 style="color:white">Datesheet</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/syllabus.php" target="_blank"><h4 style="color:white">Syllabus</h4></a></li>
							
							</ul>
								<div class="clear"></div>
							</div>
						
						</div>
						<div class="span3">
						
							<h3 style="text-align:center">Centers Zone</h3>
							<div class="">
							<ul style="text-align:center">
							<li><a href="http://www.ruralurbanskills.edu.in/downloads/Admission-Form.pdf" target="_blank"><h4 style="color:white">Admission Form</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/apply-center.php" target="_blank"><h4 style="color:white">Apply Center</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/centre-list.php" target="_blank"><h4 style="color:white">Centers List</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/approvals.php" target="_blank"><h4 style="color:white">Affiliation</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/approvals-download.php" target="_blank"><h4 style="color:white">Approvals</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/sitemap.php" target="_blank"><h4 style="color:white">All Pages Sitemap</h4></a></li>
							
							</ul>
								<div class="clear"></div>
							</div>
						
						</div>
						  <div class="span12"> <h4 style="color:white;" align="center">Copyrights &copy; 2017 All Rights Reserved. Rural Urban Council of Skills & Vocational Studies.</h4></div>
				
					<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
					
					</div>
					<!-- end: Row -->	
				
				</div>
				<!-- end: Container  -->

			</div>
			<!-- end: Footer -->
	
		</div>
		<!-- end: Container  -->

	
	</div>
	<!-- end: Wrapper  -->


	<!-- start: Copyright -->
	
	<!-- end: Copyright -->

<!-- start: Java Script -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="js/jquery-1.8.2.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/flexslider.js"></script>
<script src="js/carousel.js"></script>
<script def src="js/custom.js"></script>
<!-- end: Java Script -->

</body>
</html>
