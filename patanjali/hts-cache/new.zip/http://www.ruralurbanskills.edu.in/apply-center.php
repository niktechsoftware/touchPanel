<!DOCTYPE html>
<html lang="en">
<head>

	<!-- start: Meta -->
	<meta charset="utf-8">
	<title>Apply PTT, NPTT, NTT Center, Franchise, Study Center in India</title> 
    <meta name="description" content="Apply now for NTT PTT NPTT Health Worker, Social Worker, Computer Operator, Computer Teacher Course Franchise, Center, and Study Center in India.">
    
<meta name="keywords" content="Apply PTT, NPTT, NTT Center, Franchise, Study Center in India">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="shortcut icon" href="img/rucsvsicon.png" />
		
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/bootstrap-responsive.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Sans:400,700">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Serif">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Boogaloo">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Economica:700,400italic">
    <script type="text/javascript">
function talentvalidate()
{
	if(document.register_form.director.value=="") 
	{
    alert('Please enter director name.');
    document.register_form.director.focus();
    return false;
	}
	if(document.register_form.institute_name.value=="") 
	{
    alert('Please enter center name.');
    document.register_form.institute_name.focus();
    return false;
	}
	if(document.register_form.email.value=="") 
	{
    alert('Please enter email address.');
    document.register_form.email.focus();
    return false;
	}
	if(document.register_form.email.value!="")
	{
		var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		if (!filter.test(document.register_form.email.value)) 
		{
		alert('Please enter valid email address.');
		document.register_form.email.focus();
		return false;
		}
	}
	if(document.register_form.mobile.value=="") 
	{
    alert('Please enter mobile number.');
    document.register_form.mobile.focus();
    return false;
	}
	if(isNaN(document.register_form.mobile.value)||document.register_form.mobile.value.indexOf(" ")!=-1)
	{
	alert("Please enter numeric value.");
	document.register_form.mobile.focus();
	return false; 
	}
	if(document.register_form.mobile.value.length!=10)
	{
	alert("Please enter 10 digit mobile number.");
	document.register_form.mobile.focus();
	return false;
	}
	if (document.register_form.mobile.value.charAt(0)!="9" && document.register_form.mobile.value.charAt(0)!="8" && document.register_form.mobile.value.charAt(0)!="7")
	{
	alert("it should start with 9 or 8 or 7");
	document.register_form.mobile.focus();
	return false;
	}
	
	if(document.register_form.address.value=="") 
	{
    alert('Please enter address.');
    document.register_form.address.focus();
    return false;
	}
	if(document.register_form.state.value=="") 
	{
    alert('Please enter state.');
    document.register_form.state.focus();
    return false;
	}
	
	
}		   
</script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-124030743-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-124030743-1');
</script>
</head>
<body>
	
	
	<div id="wrapper" style="border-radius:10px;border:2px solid blue">
		<div class="container-fluid">
			<header>
				<div class="row" style="margin-left:0px">
					<div class="logo span12">
						<a class="brand" href="#"><img src="/img/logo.gif"></a>
					</div>
				</div>
						
			</header>
			<div class="navbar navbar-inverse" style="margin-bottom:0px">
    			<div class="navbar-inner">
        			<div class="container">
          				<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
            				<span class="icon-bar"></span>
            				<span class="icon-bar"></span>
            				<span class="icon-bar"></span>
          				</a>
          				<div class="nav-collapse collapse" >
            				<ul class="nav">
              					<li class="active" style="border-right:1px solid white"><a href="http://www.ruralurbanskills.edu.in"><b>Home</b></a></li>
              					<li style="border-right:1px solid white" class="dropdown">
                					<a href="#" class="dropdown-toggle" data-toggle="dropdown"><b>About Us</b> <b class="caret" style="color:white"></b></a>
                					<ul class="dropdown-menu">
                  						<li><a href="http://www.ruralurbanskills.edu.in/about.php" target="_blank">About Us</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/about.php" target="_blank">Vision/ Mission</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/director-message.php" target="_blank">Director Message</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/secretary-message.php" target="_blank">Secretary Message</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/why-rucsvs.php" target="_blank">Why RUCSVS</a></li>
                                        <li><a href="http://www.ruralurbanskills.edu.in/team.php" target="_blank">Team Members</a></li>
                                        <li><a href="http://www.ruralurbanskills.edu.in/rti.php" target="_blank">RTI</a></li>
                					</ul>
              					</li>
								<li style="border-right:1px solid white"><a href="http://www.ruralurbanskills.edu.in/trade-courses.php" target="_blank"><b>Trade Courses</b></a></li>
								<li style="border-right:1px solid white"><a href="http://www.ruralurbanskills.edu.in/course-list.php" target="_blank"><b>Courses</b></a></li>
              					<li style="border-right:1px solid white" class="dropdown">
                					<a href="#" class="dropdown-toggle" data-toggle="dropdown"><b>Student Zone</b> <b class="caret" style="color:white"></b></a>
                					<ul class="dropdown-menu">
                                        <li><a href="http://www.ruralurbanskills.edu.in/student-verification.php" target="_blank">Verification</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/admitcard-list.php" target="_blank">Admit Card</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/result-list.php" target="_blank">Result</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/exam-download.php" target="_blank">Datesheet</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/admission-enquiry.php" target="_blank">Admission Form</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/syllabus.php">Syllabus</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/course-list.php" target="_blank">Courses</a></li>
										<li><a href="http://www.ruralurbanskills.edu.in/student-benefits.php">Student Benefits</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/downloads/Rural%20Urban%20Council%20of%20Skills%20Prospectus.pdf" target="_blank">Prospectus</a></li>
										<li><a href="http://www.ruralurbanskills.edu.in/cancellation-policy.php" target="_blank">Cancellation Policy</a></li>
                                        <li><a href="http://www.ruralurbanskills.edu.in/student-terms.php" target="_blank">Terms & Conditions</a></li>
                  						
										
										
                					</ul>
              					</li>
								<li style="border-right:1px solid white" class="dropdown">
                					<a href="#" class="dropdown-toggle" data-toggle="dropdown"><b>Downloads</b> <b class="caret" style="color:white"></b></a>
                					<ul class="dropdown-menu">
                  						<li><a href="http://www.ruralurbanskills.edu.in/approvals-download.php" target="_blank">Approval Letters </a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/center-download.php" target="_blank">Centers Download Zone</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/student-download.php" target="_blank">Student Download Zonesheet</a></li>
                                        <li><a href="http://www.ruralurbanskills.edu.in/exam-download.php">Exam Download Zonesheet</a></li>
                                        <li><a href="http://www.ruralurbanskills.edu.in/downloads/RUCSVS-Courses-&-Code.pdf" target="_blank">Courses Code</a></li>
                                        <li><a href="http://www.ruralurbanskills.edu.in/center-benefits.php" target="_blank">Centers Benefits</a></li>
                                        <li><a href="http://www.ruralurbanskills.edu.in/news-press-release.php" target="_blank">News/ Press Release</a></li>
                  						
                					</ul>
              					</li>
								<li style="border-right:1px solid white"><a href="http://www.ruralurbanskills.edu.in/centre-list.php" target="_blank"><b>Centre List</b></a></li>
              					<li style="border-right:1px solid white"><a href="http://www.ruralurbanskills.edu.in/apply-center.php" target="_blank"><b>Apply Centre</b></a></li>
              					<li style="border-right:1px solid white"><a href="http://www.ruralurbanskills.edu.in/contact.php" target="_blank"><b>Contact</b></a></li>
              					
								
            				</ul>
          				</div>
        			</div>
      			</div>
    		</div>
            
			<!--end: Navigation-->
			
		</div>
		<!--end: Container-->
		
			
		<!--start: Container -->
    	<div class="container-fluid" style="padding-top:10px">
	      <div class="row">
		 
		  <div class="span3" style="background-color:#68cdfb;border-radius:5px">
		  <div style="padding-left:5px;padding-right:5px">
                    
		<div style="background:#68cdfb;margin-bottom:5px;">
       
  <h4 class="mycolor" style="color:white;padding:8px;text-align:center;margin-bottom:0px">Information About</h4>
		<div style="background:#68cdfb;margin-bottom:5px;">
       
					<ul style="color:red;padding:10px;" class="text-center">
					<li style="background: url(/img/bullet1.gif) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/sitemap.php"  style="color:black" target="_blank"><p style="color:black;padding-left:15px;font-weight:600;margin-top:10px">All Pages Sitemap</p></a></li>
					<hr style="border-top: 1px solid blue;border-bottom: 1px solid #0088cc;margin:0px">
				    <li style="background: url(/img/bullet1.gif) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/student-verification.php"  style="color:black" target="_blank"><p style="color:black;padding-left:15px;font-weight:600;margin-top:10px">Verification</p></a></li>
					<hr style="border-top: 1px solid blue;border-bottom: 1px solid #0088cc;margin:0px">
					<li style="background: url(/img/bullet1.gif) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/apply-center.php"  style="color:black" target="_blank"><p style="color:black;padding-left:15px;font-weight:600;margin-top:10px">Apply Center</p></a></li>
					<hr style="border-top: 1px solid blue;border-bottom: 1px solid #0088cc;margin:0px">
					<li style="background: url(/img/bullet1.gif) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/center-login-panel.php"  style="color:black" target="_blank"><p style="color:black;padding-left:15px;font-weight:600;margin-top:10px">Center Login Panel</p></a></li>
					<hr style="border-top: 1px solid blue;border-bottom: 1px solid #0088cc;margin:0px">
					<li style="background: url(/img/bullet1.gif) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/center-download.php"  style="color:black" target="_blank"><p style="color:black;padding-left:15px;font-weight:600;margin-top:10px">Center Download</p></a></li>
					<hr style="border-top: 1px solid blue;border-bottom: 1px solid #0088cc;margin:0px">
					<li style="background: url(/img/bullet1.gif) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/admission-enquiry.php"  style="color:black" target="_blank"><p style="color:black;padding-left:15px;font-weight:600;margin-top:10px">Apply Admission Zone</p></a></li>
					<hr style="border-top: 1px solid blue;border-bottom: 1px solid #0088cc;margin:0px">
					<li style="background: url(/img/bullet1.gif) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/course-list.php"  style="color:black" target="_blank"><p style="color:black;padding-left:15px;font-weight:600;margin-top:10px">Courses & Duration</p></a></li>
					<hr style="border-top: 1px solid blue;border-bottom: 1px solid #0088cc;margin:0px">
					<li style="background: url(/img/bullet1.gif) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/student-download.php"  style="color:black" target="_blank"><p style="color:black;padding-left:15px;font-weight:600;margin-top:10px">Student Downloads</p></a></li>
					<hr style="border-top: 1px solid blue;border-bottom: 1px solid #0088cc;margin:0px">
					<li style="background: url(/img/bullet1.gif) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/centers-terms.php"  style="color:black" target="_blank"><p style="color:black;padding-left:15px;font-weight:600;margin-top:10px">Center Terms & Conditions</p></a></li>
					<hr style="border-top: 1px solid blue;border-bottom: 1px solid #0088cc;margin:0px">
					<li style="background: url(/img/bullet1.gif) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/approvals.php"  style="color:black" target="_blank"><p style="color:black;padding-left:15px;font-weight:600;margin-top:10px">Recognition</p></a></li>
					<hr style="border-top: 1px solid blue;border-bottom: 1px solid #0088cc;margin:0px">
					<li style="background: url(/img/bullet1.gif) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/centre-list.php"  style="color:black" target="_blank"><p style="color:black;padding-left:15px;font-weight:600;margin-top:10px">Centers List</p></a></li>
					<hr style="border-top: 1px solid blue;border-bottom: 1px solid #0088cc;margin:0px">
					<li style="background: url(/img/bullet1.gif) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/approvals-download.php"  style="color:black" target="_blank"><p style="color:black;padding-left:15px;font-weight:600;margin-top:10px">Approval Downloads</p></a></li>
<hr style="border-top: 1px solid blue;border-bottom: 1px solid #0088cc;margin:0px">
<li style="background: url(/img/bullet1.gif) no-repeat 5px 2px;padding-left:20px"><a href="http://www.ruralurbanskills.edu.in/all-centers.php"  style="color:black" target="_blank"><p style="color:black;padding-left:15px;font-weight:600;margin-top:10px">All Centers</p></a></li>
					
					</ul></div></div>
                        </div>
						
						</div>
		  
		  
			<!-- start: Flexslider -->
			<div class="span9">
			
			<div style="padding:16px 20px">
			<div class="title" align="center" ><h3><strong>APPLY CENTER FORM-CALL @ <br>Ms. Savita 09560192015 / <br>Ms. Shalu 09899822580 </h3><br><h4>( Timing 11 am to 6 pm Mon to Sat Only )<br> CENTER FEE APPLICABLE <br> Pay Fees only in Our Mentioned Accounts <a href="http://www.ruralurbanskills.edu.in/payment.php" target="_blank">CLICK HERE</a></strong></h4></div>
             
				<!-- start: Contact Form -->
				<div id="contact-form" style="background:#ede080;border-radius:5px;padding:16px 20px">
					
					<form name="register_form" action="" method="post" class="cmxform" onSubmit="return talentvalidate()">
								<div style="color:#FF0000; font-family:Arial; padding-left:120px;"></div>
					<fieldset>
						  <div class="span6">
						  <div class="clearfix">
								<label for="name"><span>Director's Name:<span style="color:red">*</span></span></label>
								<div class="input">
									<input tabindex="1" style="width:95%" id="name" name="director"  type="text" value="">
								</div>
							</div>
							<div class="clearfix">
								<label for="email"><span>Email Id:<span style="color:red">*</span></span></label>
								<div class="input">
									<input tabindex="2" style="width:95%" id="email" name="email" type="text" value="" Placeholder="Enter Email Id" class="input-xlarge" value="">
								</div>
							</div>
							
							
							<div class="clearfix">
								<label for="email"><span>State:<span style="color:red">*</span></span></label>
								<div class="input">
									<select class="form-control" id="sel1" style="width:100%;height:40px" name="state">
                                    <option value="">Select State</option>

                        <option value="Andaman & Nicobar">Andaman & Nicobar</option>

                     <option value="Andhra Pradesh">Andhra Pradesh</option>

                     <option value="Arunachal Pradesh">Arunachal Pradesh</option>

                     <option value="Assam">Assam</option>

                     <option value="Bihar">Bihar</option>

                     <option value="Chandigarh">Chandigarh</option>

                     <option value="Chhattisgarh">Chhattisgarh</option>

                     <option value="Dadra &Nagar Haveli">Dadra &Nagar Haveli</option>

                     <option value="Daman & Diu">Daman & Diu</option>

                     <option value="Delhi NCR">Delhi NCR</option>

                     <option value="Goa">Goa</option>

                     <option value="Gujarat">Gujarat</option>

                     <option value="Haryana">Haryana</option>

                     <option value="Himachal Pradesh">Himachal Pradesh</option>

                     <option value="Jammu & Kashmir">Jammu & Kashmir</option>

                     <option value="Jharkhand">Jharkhand</option>

                     <option value="Karnataka">Karnataka</option>

                     <option value="Kerala">Kerala</option>

                     <option value="Lakshadweep">Lakshadweep</option>

                     <option value="Madhya Pradesh">Madhya Pradesh</option>

                     <option value="Maharashtra">Maharashtra</option>

                     <option value="Manipur">Manipur</option>

                     <option value="Meghalaya">Meghalaya</option>

                     <option value="Mizoram">Mizoram</option>

                     <option value="Nagaland">Nagaland</option>

                     <option value="Orissa">Orissa</option>

                     <option value="Pondicherry">Pondicherry</option>

                     <option value="Punjab">Punjab</option>

                     <option value="Rajasthan">Rajasthan</option>

                     <option value="Sikkim">Sikkim</option>

                     <option value="Tamil Nadu">Tamil Nadu</option>

                     <option value="Tripura">Tripura</option>

                     <option value="Uttar Pradesh">Uttar Pradesh</option>

                     <option value="Uttarakhand">Uttarakhand</option>

                     <option value="West Bengal">West Bengal</option>

                     

                             </select>
				</div>
							</div>
						  <div class="clearfix">
								<label for="email"><span>Address:<span style="color:red">*</span></span></label>
								<div class="input">
									<input tabindex="2" style="width:95%"  name="address" type="text" value="" class="input-xlarge" value="">
								</div>
							</div>
						  </div>
			    <div class="span6">
				<div class="clearfix">
								<label for="name"><span>Center Name:<span style="color:red">*</span></span></label>
								<div class="input">
									<input tabindex="1" style="width:95%" id="name" name="institute_name" type="text" value="" value="">
								</div>
							</div>
							
							<div class="clearfix">
								<label for="name"><span>Mobile Number:<span style="color:red">*</span></span></label>
								<div class="input">
									<input type="text" style="width:95%" name="mobile"   value="">
								</div>
							</div>
							<div class="clearfix">
								<label for="email"><span>Alternate Mobile Number:</span></label>
								<div class="input">
									<input tabindex="2" style="width:95%"  name="mobile2" type="text"  class="input-xlarge" value="">
								</div>
							</div>
							<div class="clearfix">
								<label for="email"><span>City:</span></label>
								<div class="input">
									<input tabindex="2" style="width:95%"  name="city" type="text" value="" class="input-xlarge" value="">
								</div>
							</div>
							
							
							
							
				
				</div>
				<div class="span6" style="text-align:center">
				<div class="actions">
				<hr/>
								<input tabindex="3" type="submit" class="btn btn-danger btn-large" name="submit3" value="SUBMIT HERE">
									</div>
				</div>
			
							

							

							

							
						</fieldset>
					
					</form>
					
				</div>
			
			</div>
            <div align="center"><a href="http://www.ruralurbanskills.edu.in/centre-list.php" class="btn btn-success btn-large" target="_blank">All India Centers List</a></div><br>
            <div align="center"><a href="http://www.ruralurbanskills.edu.in/sitemap.php" class="btn btn-success btn-large" target="_blank">All Pages Sitemap Link</a></div>
			<br>
            <div align="center"><a href="http://www.ruralurbanskills.edu.in/center-benefits.php" class="btn btn-success btn-large" target="_blank">Our Center Benefits</a></div>
			<br>
            <div align="center"><a href="http://www.ruralurbanskills.edu.in/center-login-panel.php" class="btn btn-success btn-large" target="_blank">Center Login Panel</a></div>
			<br>
			<!-- end: Hero Unit -->
				<div class="span6" style="text-align:center">
				<div class="actions">
				<hr/>
							<div>	
								
							</div>
				</div>
                
						
							
            </div>
			</div>
            
			
			
			<!-- end: Row -->
      		<div class="row">
			<div class="span2" style="background-color:white;text-align:center">
			<img src="img/beti.png" style="height:120px"/>
			
			</div>
			<div class="span2" style="background-color:white;text-align:center">
			<img src="img/beti2.png" style="height:120px"/>
			
			</div>
			<div class="span2" style="background-color:white;text-align:center">
			<img src="img/skill.png" style="height:120px"/>
			
			</div>
			<div class="span3" style="background-color:white;text-align:center">
			<img src="img/shiksha.jpg" style="height:120px"/>
			
			</div>
			<div class="span3" style="background-color:white;text-align:center">
			<img src="img/swach.jpg" style="height:120px"/>
			
			</div>
			
			
			</div><hr/>
		
			<!-- start Clients List -->	
			<div class="clients-carousel" style="border:2px solid green;border-radius:7px">
		<h3 class="mycolor2" style="text-align:center;color:white;margin:0px">Image Gallery</h3>
				<ul class="slides clients">
					<li><img src="img/logos/1.png" alt=""/></li>
					<li><img src="img/logos/2.png" alt=""/></li>	
					<li><img src="img/logos/3.png" alt=""/></li>
					<li><img src="img/logos/4.png" alt=""/></li>
					<li><img src="img/logos/5.png" alt=""/></li>
					<li><img src="img/logos/6.png" alt=""/></li>
					<li><img src="img/logos/7.png" alt=""/></li>
					<li><img src="img/logos/8.png" alt=""/></li>
					<li><img src="img/logos/9.png" alt=""/></li>
					<li><img src="img/logos/10.png" alt=""/></li>		
				</ul>
		
			</div>
            
			
		</div>
		<!--end: Container-->
				
	<!--start: Container -->
    	<div class="container-fluid">		

      		<div id="footer">
			
				<!-- start: Container -->
				<div class="container">
				
					<!-- start: Row -->
					<div class="row">

						<!-- start: About -->
						<div class="span3">
						
							<h3 style="text-align:center">About Us</h3>
							<p>
								This is a small step to decide on your participation in Skillful India, but by making a meaningful effort with sincere and transparent thinking, we will continue to make every effort to make it a milestone. <br /> <strong><font size="+1">For Center Apply Helpline 09560192015 , 09899822580</font> </strong>
							</p>
							
						</div>
						<!-- end: About -->

						<!-- start: Photo Stream -->
						<div class="span3">
						
							<h3 style="text-align:center">Downloads</h3>
							<div class="">
							<ul style="text-align:center">
							<li><a href="http://www.ruralurbanskills.edu.in/downloads/Admission-Form.pdf" target="_blank"><h4 style="color:white">Admission Form</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/downloads/Rural%20Urban%20Council%20of%20Skills%20Prospectus.pdf" target="_blank"><h4 style="color:white">Prospectus</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/downloads/Examination%20Center%20Request%20Form.pdf" target="_blank"><h4 style="color:white">Exam Center Form</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/downloads/dublicate%20marksheet%20form.pdf" target="_blank"><h4 style="color:white">Duplicate Marksheet</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/downloads/marksheet-correction-form.pdf" target="_blank"><h4 style="color:white">Correction Form</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/downloads/Re-Registration-Form.pdf" target="_blank"><h4 style="color:white">Re Registration</h4></a></li>
							
							</ul>
								<div class="clear"></div>
							</div>
						
						</div>
						<!-- end: Photo Stream -->
                        <div class="span3">
						
							<h3 style="text-align:center">Student Zone</h3>
							<div class="">
							<ul style="text-align:center">
							<li><a href="http://www.ruralurbanskills.edu.in/admission-enquiry.php" target="_blank"><h4 style="color:white">Apply Admission</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/result-list.php" target="_blank"><h4 style="color:white">Result Zone</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/admitcard-list.php" target="_blank"><h4 style="color:white">Admit Card</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/student-verification.php" target="_blank"><h4 style="color:white">Online Verification</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/exam-download.php" target="_blank"><h4 style="color:white">Datesheet</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/syllabus.php" target="_blank"><h4 style="color:white">Syllabus</h4></a></li>
							
							</ul>
								<div class="clear"></div>
							</div>
						
						</div>
						<div class="span3">
						
							<h3 style="text-align:center">Centers Zone</h3>
							<div class="">
							<ul style="text-align:center">
							<li><a href="http://www.ruralurbanskills.edu.in/downloads/Admission-Form.pdf" target="_blank"><h4 style="color:white">Admission Form</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/apply-center.php" target="_blank"><h4 style="color:white">Apply Center</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/centre-list.php" target="_blank"><h4 style="color:white">Centers List</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/approvals.php" target="_blank"><h4 style="color:white">Affiliation</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/approvals-download.php" target="_blank"><h4 style="color:white">Approvals</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/sitemap.php" target="_blank"><h4 style="color:white">All Pages Sitemap</h4></a></li>
							
							</ul>
								<div class="clear"></div>
							</div>
						
						</div>
						  <div class="span12"> <h4 style="color:white;" align="center">Copyrights &copy; 2017 All Rights Reserved. Rural Urban Council of Skills & Vocational Studies.</h4></div>
				
					<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
					
					</div>
					<!-- end: Row -->	
				
				</div>
				<!-- end: Container  -->

			</div>
			<!-- end: Footer -->
	
		</div>
		<!-- end: Container  -->

		</div>
	<!-- end: Wrapper  -->


	<!-- start: Copyright -->
	
	<!-- end: Copyright -->

<!-- start: Java Script -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="js/jquery-1.8.2.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/flexslider.js"></script>
<script src="js/carousel.js"></script>
<script def src="js/custom.js"></script>
<!-- end: Java Script -->

</body>
</html>
