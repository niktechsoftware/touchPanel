<!DOCTYPE html>
<html lang="en">
<head>

	<!-- start: Meta -->
	<meta charset="utf-8">
	<title>Skills, Vocational, Early Childhood Courses Admission Institute</title> 
    <meta name="description" content="Get complete list of Skills, Vocational, Early Childhood Courses Admission in India. Rural Urban Council of Skills & Vocational Studies Institute provides Skills, Vocational, Early Childhood Courses in India.">
    
<meta name="keywords" content="Skills, Vocational, Early Childhood Courses Admission Institute">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <link rel="shortcut icon" href="img/rucsvsicon.png" />
		
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/bootstrap-responsive.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Sans:400,700">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Droid+Serif">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Boogaloo">
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Economica:700,400italic">
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-124030743-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-124030743-1');
</script>
</head>
<body>
	
	
	<div id="wrapper" style="border-radius:10px;border:2px solid blue">
								<div class="container-fluid">
			<header>
				<div class="row" style="margin-left:0px">
					<div class="logo span12">
						<a class="brand" href="#"><img src="/img/logo.gif"></a>
					</div>
				</div>
						
			</header>
			<div class="navbar navbar-inverse" style="margin-bottom:0px">
    			<div class="navbar-inner">
        			<div class="container">
          				<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
            				<span class="icon-bar"></span>
            				<span class="icon-bar"></span>
            				<span class="icon-bar"></span>
          				</a>
          				<div class="nav-collapse collapse" >
            				<ul class="nav">
              					<li class="active" style="border-right:1px solid white"><a href="http://www.ruralurbanskills.edu.in"><b>Home</b></a></li>
              					<li style="border-right:1px solid white" class="dropdown">
                					<a href="#" class="dropdown-toggle" data-toggle="dropdown"><b>About Us</b> <b class="caret" style="color:white"></b></a>
                					<ul class="dropdown-menu">
                  						<li><a href="http://www.ruralurbanskills.edu.in/about.php" target="_blank">About Us</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/about.php" target="_blank">Vision/ Mission</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/director-message.php" target="_blank">Director Message</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/secretary-message.php" target="_blank">Secretary Message</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/why-rucsvs.php" target="_blank">Why RUCSVS</a></li>
                                        <li><a href="http://www.ruralurbanskills.edu.in/team.php" target="_blank">Team Members</a></li>
                                        <li><a href="http://www.ruralurbanskills.edu.in/rti.php" target="_blank">RTI</a></li>
                					</ul>
              					</li>
								<li style="border-right:1px solid white"><a href="http://www.ruralurbanskills.edu.in/trade-courses.php" target="_blank"><b>Trade Courses</b></a></li>
								<li style="border-right:1px solid white"><a href="http://www.ruralurbanskills.edu.in/course-list.php" target="_blank"><b>Courses</b></a></li>
              					<li style="border-right:1px solid white" class="dropdown">
                					<a href="#" class="dropdown-toggle" data-toggle="dropdown"><b>Student Zone</b> <b class="caret" style="color:white"></b></a>
                					<ul class="dropdown-menu">
                                        <li><a href="http://www.ruralurbanskills.edu.in/student-verification.php" target="_blank">Verification</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/admitcard-list.php" target="_blank">Admit Card</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/result-list.php" target="_blank">Result</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/exam-download.php" target="_blank">Datesheet</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/admission-enquiry.php" target="_blank">Admission Form</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/syllabus.php">Syllabus</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/course-list.php" target="_blank">Courses</a></li>
										<li><a href="http://www.ruralurbanskills.edu.in/student-benefits.php">Student Benefits</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/downloads/Rural%20Urban%20Council%20of%20Skills%20Prospectus.pdf" target="_blank">Prospectus</a></li>
										<li><a href="http://www.ruralurbanskills.edu.in/cancellation-policy.php" target="_blank">Cancellation Policy</a></li>
                                        <li><a href="http://www.ruralurbanskills.edu.in/student-terms.php" target="_blank">Terms & Conditions</a></li>
                  						
										
										
                					</ul>
              					</li>
								<li style="border-right:1px solid white" class="dropdown">
                					<a href="#" class="dropdown-toggle" data-toggle="dropdown"><b>Downloads</b> <b class="caret" style="color:white"></b></a>
                					<ul class="dropdown-menu">
                  						<li><a href="http://www.ruralurbanskills.edu.in/approvals-download.php" target="_blank">Approval Letters </a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/center-download.php" target="_blank">Centers Download Zone</a></li>
                  						<li><a href="http://www.ruralurbanskills.edu.in/student-download.php" target="_blank">Student Download Zonesheet</a></li>
                                        <li><a href="http://www.ruralurbanskills.edu.in/exam-download.php">Exam Download Zonesheet</a></li>
                                        <li><a href="http://www.ruralurbanskills.edu.in/downloads/RUCSVS-Courses-&-Code.pdf" target="_blank">Courses Code</a></li>
                                        <li><a href="http://www.ruralurbanskills.edu.in/center-benefits.php" target="_blank">Centers Benefits</a></li>
                                        <li><a href="http://www.ruralurbanskills.edu.in/news-press-release.php" target="_blank">News/ Press Release</a></li>
                  						
                					</ul>
              					</li>
								<li style="border-right:1px solid white"><a href="http://www.ruralurbanskills.edu.in/centre-list.php" target="_blank"><b>Centre List</b></a></li>
              					<li style="border-right:1px solid white"><a href="http://www.ruralurbanskills.edu.in/apply-center.php" target="_blank"><b>Apply Centre</b></a></li>
              					<li style="border-right:1px solid white"><a href="http://www.ruralurbanskills.edu.in/contact.php" target="_blank"><b>Contact</b></a></li>
              					
								
            				</ul>
          				</div>
        			</div>
      			</div>
    		</div>
            
			<!--end: Navigation-->
			
		</div>
		<!--end: Container-->
		
				<!--end: Container-->
				
		<!--start: Container -->
    	<div class="container-fluid" style="padding-top:10px">
		<div class="row">
<div class="span12">
		<h1 style="color:white;background:#21186E;text-align:center;padding:4px;margin-bottom:20px">Skills, Vocational, Early Childhood Courses Admission</h1>
		</div>
                          
                           <div class="span12">
						   <p align="center"><b><font size="+1" style="color:#FF3300">Self Study/ Private Mode/ Training Based Diploma/ Certificate Courses</font> </b></p>
                            <table class="table table-striped table-bordered table-hover table-responsive">
              <thead>

                 
                <tr  style="text-align:center;background:#89c236;color:white">
                    <th rowspan="2" style="text-align:center">Serial No.</th>
                    <th rowspan="2" style="text-align:center">Title of Programme</th>
					<th rowspan="2" style="text-align:center">Eligibility</th>
					<th colspan="2" style="text-align:center">Course Duration</th>
					                  
					
                </tr>
				
              </thead>
			  <tbody>
			 
			  <tr>
					<td align="center">1</td>
					<td>NGO MANAGEMENT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">2</td>
					<td>PLAYBACK SINGING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">3</td>
					<td>DANCE CHOREOGRAPHY</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">4</td>
					<td>ASTROLOGY</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">5</td>
					<td>CORPORATE TRAINING & DEVELOPMENT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">6</td>
					<td>PRINT MEDIA</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">7</td>
					<td>POULTRY PRODUCTION</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">8</td>
					<td>EMERGENCY MEDICAL TECHNICIAN</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">9</td>
					<td>NURSING CARE ASSISTANT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">10</td>
					<td>AUTO BODY REPAIR TECHNICIAN</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">11</td>
					<td>RETAIL BRAND ASSISTANT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">12</td>
					<td>HOTEL RECEPTION & BOOK KEEPING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">13</td>
					<td>LEATHER PROCESSING/TANNING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">14</td>
					<td>AC SERVICE AND REPAIR</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">15</td>
					<td>PALM PRODUCT TECHNOLOGY</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">16</td>
					<td>MUSIC & INSTRUMENTS</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">17</td>
					<td>CAR DRIVING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">18</td>
					<td>MOBILE REPAIRING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">19</td>
					<td>MOTOR PUMPS MECHANIC</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">20</td>
					<td>FOOTWEAR & LEATHER GOODS WORKER</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">21</td>
					<td>HANDMADE PAPER WORKER</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">22</td>
					<td>REFRIGERATOR TECHNICIAN</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">23</td>
					<td>TV TECHNICIAN</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">24</td>
					<td>DIAMOND CUTTING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">25</td>
					<td>MOTOR WINDING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">26</td>
					<td>DIESEL ENGINE/PUMP SERVICING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">27</td>
					<td>WELDING & FABRICATION</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">28</td>
					<td>PLASTIC TECHNOLOGY</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">29</td>
					<td>DETERGENT CAKE MAKING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">30</td>
					<td>LEATHER PROCESSING/TANNING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">31</td>
					<td>FIBRE TECHNOLOGY</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">32</td>
					<td>PALM PRODUCT TECHNOLOGY</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">33</td>
					<td>FRUITS & VEGETABLE PROCESSING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">34</td>
					<td>BAKERY MANUFACTURING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">35</td>
					<td>MILK PRODUCTS MANUFACTURING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">36</td>
					<td>BEE KEEPING COURSE</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">37</td>
					<td>SILK REELING & SPINNING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">38</td>
					<td>NEEDLE WORK</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">39</td>
					<td>HOSIERY COURSE</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">40</td>
					<td>TAILORING & EMBROIDERY</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">41</td>
					<td>LEATHER GOODS MAKER</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">42</td>
					<td>CANDLE MAKING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">43</td>
					<td>WOODEN WORK TECHNOLOGY</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">44</td>
					<td>WATER FALLS MAKING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">45</td>
					<td>TOY MAKING TECHNOLOGY</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">46</td>
					<td>TAILORING & GARMENT TECHNOLOGY</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">47</td>
					<td>SPA & WELLNESS MANAGEMENT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">48</td>
					<td>PAINTING TECHNOLOGY</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">49</td>
					<td>COMPUTER TEACHER TRAINING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">50</td>
					<td>MEHANDI DESIGNER</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">6 Months</td>
					
				
					
					
					</tr><tr>
					<td align="center">51</td>
					<td>GEM & JEWELLERY</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">52</td>
					<td>PHOTOGRAPHY</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">53</td>
					<td>HAIR & SKIN CARE SPECIALIST</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">54</td>
					<td>OFFICE MACHINE OPERATOR</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">55</td>
					<td>OFFICE AUTOMATION & INTERNET</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">56</td>
					<td>COMPUTER SCIENCE</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">57</td>
					<td>COMPUTER HARDWARE & NETWORKING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">58</td>
					<td>TALLY</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">59</td>
					<td>TYPING MASTER</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">60</td>
					<td>COMPUTER ACCOUNTING MANAGEMENT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">61</td>
					<td>MULTIMEDIA & ANIMATION</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">62</td>
					<td>WEB DESIGNING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">63</td>
					<td>WEB DEVELOPMENT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">64</td>
					<td>COMPUTERISED FINANCIAL ACCOUNTING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">65</td>
					<td>ADVANCED COMPUTER TEACHER TRAINING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">66</td>
					<td>COMPUTER TEACHER TRAINING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">67</td>
					<td>ONLINE PROMOTION MARKETING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">68</td>
					<td>SEO ( SEARCH ENGINE OPTIMISATION )</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">69</td>
					<td>DIGITAL MARKETING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">70</td>
					<td>DTP ( DESKTOP PUBLICATION )</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">71</td>
					<td>DATA ENTRY OPERATOR</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">72</td>
					<td>COMPUTER APPLICATION</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">73</td>
					<td>HEALTH QUALITY MANAGEMENT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">74</td>
					<td>INDUSTRIAL SAFETY MANAGEMENT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">75</td>
					<td>PRE-SCHOOL MANAGEMENT ASSISTANT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">76</td>
					<td>CATERING & HOSPITALITY ASSISTANT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">77</td>
					<td>HOSPITAL HOUSE KEEPING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">78</td>
					<td>BAR & RESTAURANT MANAGEMENT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">79</td>
					<td>RURAL MANAGEMENT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">80</td>
					<td>LANGUAGE TRANSLATION</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">81</td>
					<td>COMPUTERISED FINANCIAL ACCOUNTING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">82</td>
					<td>WRITING & EDITING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">83</td>
					<td>LIBRARY ATTENDANT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">84</td>
					<td>ENGLISH SPEAKING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">6 Months</td>
					
				
					
					
					</tr><tr>
					<td align="center">85</td>
					<td>OFFICE SECRETARYSHIP</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">86</td>
					<td>ACCOUNTANCY AND AUDITING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">87</td>
					<td>MARKETING AND SALESMANSHIP</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">88</td>
					<td>FINANCIAL MARKET MANAGEMENT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">89</td>
					<td>RETAIL SALES SERVICES</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">90</td>
					<td>COUNSELLING & GUIDANCE</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">91</td>
					<td>ENVIRONMENTAL STUDIES</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">92</td>
					<td>HEALTH RECORD MANAGEMENT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">93</td>
					<td>CRECHE MANAGEMENT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">94</td>
					<td>EVENT MANAGEMENT ASSISTANT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">95</td>
					<td>HEALTH AND SAFETY MANAGEMENT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">96</td>
					<td>COMMUNITY HEALTH WORKER</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">97</td>
					<td>SECURITY OFFICER</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">98</td>
					<td>YOUTH CARE WORKER</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">99</td>
					<td>SOCIAL WORK</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">100</td>
					<td>HEALTH & CARE</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">101</td>
					<td>PERSONALITY DEVELOPMENT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">6 Months</td>
					
				
					
					
					</tr><tr>
					<td align="center">102</td>
					<td>RETAIL TRADE & MANAGEMENT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">103</td>
					<td>MEDIA MANAGEMENT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">104</td>
					<td>ENVIRONMENT AND POLLUTION CONTROL</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">105</td>
					<td>COURIER AND LOGISTICS MANAGEMENT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">106</td>
					<td>RURAL DEVELOPMENT MANAGEMENT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">107</td>
					<td>FINANCIAL PLANNING & WEALTH MANAGEMENT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">108</td>
					<td>HEALTH & YOGA</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">109</td>
					<td>HR EXECUTIVE</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">110</td>
					<td>SOCIAL STUDIES</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">111</td>
					<td>INSTITUTION HOUSE KEEPING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">112</td>
					<td>FRONT OFFICE EXECUTIVE</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">113</td>
					<td>INSURANCE AGENT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">114</td>
					<td>OFFICE ADMINISTRATOR</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">115</td>
					<td>LIBRARY & INFORMATION SCIENCE</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">116</td>
					<td>STORE AND DISPATCH MANAGEMENT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">117</td>
					<td>HOUSE KEEPING</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">118</td>
					<td>ARTS CRAFTS</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">119</td>
					<td>CHILD CARE MANAGEMENT</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">120</td>
					<td>EARLY CHILDHOOD CARE & EDUCATION (ECCE)</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 Year</td>
					
				
					
					
					</tr><tr>
					<td align="center">121</td>
					<td>NURSERY PRIMARY TEACHER TRAINING (NPTT)</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 or 2 Years</td>
					
				
					
					
					</tr><tr>
					<td align="center">122</td>
					<td>PRIMARY TEACHER TRAINING (PTT)</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 or 2 Years</td>
					
				
					
					
					</tr><tr>
					<td align="center">123</td>
					<td>NURSERY TEACHER TRAINING ( NTT)</td>
					<td align="center">Min. 12th Pass</td>
					<td align="center">1 or 2 Years</td>
					
				
					
					
					</tr>		
					
								
			  </tbody>
              
          </table>

                      </div>
                           

                           

                        </div>
	  
			</div>
			
			
		<!--end: Container-->
				
							<!--start: Container -->
    	<div class="container-fluid">		

      		<div id="footer">
			
				<!-- start: Container -->
				<div class="container">
				
					<!-- start: Row -->
					<div class="row">

						<!-- start: About -->
						<div class="span3">
						
							<h3 style="text-align:center">About Us</h3>
							<p>
								This is a small step to decide on your participation in Skillful India, but by making a meaningful effort with sincere and transparent thinking, we will continue to make every effort to make it a milestone. <br /> <strong><font size="+1">For Center Apply Helpline 09560192015 , 09899822580</font> </strong>
							</p>
							
						</div>
						<!-- end: About -->

						<!-- start: Photo Stream -->
						<div class="span3">
						
							<h3 style="text-align:center">Downloads</h3>
							<div class="">
							<ul style="text-align:center">
							<li><a href="http://www.ruralurbanskills.edu.in/downloads/Admission-Form.pdf" target="_blank"><h4 style="color:white">Admission Form</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/downloads/Rural%20Urban%20Council%20of%20Skills%20Prospectus.pdf" target="_blank"><h4 style="color:white">Prospectus</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/downloads/Examination%20Center%20Request%20Form.pdf" target="_blank"><h4 style="color:white">Exam Center Form</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/downloads/dublicate%20marksheet%20form.pdf" target="_blank"><h4 style="color:white">Duplicate Marksheet</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/downloads/marksheet-correction-form.pdf" target="_blank"><h4 style="color:white">Correction Form</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/downloads/Re-Registration-Form.pdf" target="_blank"><h4 style="color:white">Re Registration</h4></a></li>
							
							</ul>
								<div class="clear"></div>
							</div>
						
						</div>
						<!-- end: Photo Stream -->
                        <div class="span3">
						
							<h3 style="text-align:center">Student Zone</h3>
							<div class="">
							<ul style="text-align:center">
							<li><a href="http://www.ruralurbanskills.edu.in/admission-enquiry.php" target="_blank"><h4 style="color:white">Apply Admission</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/result-list.php" target="_blank"><h4 style="color:white">Result Zone</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/admitcard-list.php" target="_blank"><h4 style="color:white">Admit Card</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/student-verification.php" target="_blank"><h4 style="color:white">Online Verification</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/exam-download.php" target="_blank"><h4 style="color:white">Datesheet</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/syllabus.php" target="_blank"><h4 style="color:white">Syllabus</h4></a></li>
							
							</ul>
								<div class="clear"></div>
							</div>
						
						</div>
						<div class="span3">
						
							<h3 style="text-align:center">Centers Zone</h3>
							<div class="">
							<ul style="text-align:center">
							<li><a href="http://www.ruralurbanskills.edu.in/downloads/Admission-Form.pdf" target="_blank"><h4 style="color:white">Admission Form</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/apply-center.php" target="_blank"><h4 style="color:white">Apply Center</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/centre-list.php" target="_blank"><h4 style="color:white">Centers List</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/approvals.php" target="_blank"><h4 style="color:white">Affiliation</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/approvals-download.php" target="_blank"><h4 style="color:white">Approvals</h4></a></li>
							<li><a href="http://www.ruralurbanskills.edu.in/sitemap.php" target="_blank"><h4 style="color:white">All Pages Sitemap</h4></a></li>
							
							</ul>
								<div class="clear"></div>
							</div>
						
						</div>
						  <div class="span12"> <h4 style="color:white;" align="center">Copyrights &copy; 2017 All Rights Reserved. Rural Urban Council of Skills & Vocational Studies.</h4></div>
				
					<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
					
					</div>
					<!-- end: Row -->	
				
				</div>
				<!-- end: Container  -->

			</div>
			<!-- end: Footer -->
	
		</div>
		<!-- end: Container  -->

	
	</div>
	<!-- end: Wrapper  -->


	<!-- start: Copyright -->
	
	<!-- end: Copyright -->

<!-- start: Java Script -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="js/jquery-1.8.2.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/flexslider.js"></script>
<script src="js/carousel.js"></script>
<script def src="js/custom.js"></script>
<!-- end: Java Script -->

</body>
</html>
